//Created by Jubril Bakare 4/25/2019

var jsonData = JSON.parse(localStorage.getItem('studentList'));
var dropdownVal = 10;
var index;

if(jsonData == null){
jsonData = [];}

$.fn.mergeObj = function(obj){
    var a = $.map(obj, function(value){
        return value;
    });
    return a.join(" | ");
}

$("#dropdown").change(function () {
    if($("#dropdown").val() == "All"){
        dropdownVal = jsonData.length;
    } else {
    dropdownVal = $("#dropdown").val();
    }
    createTable();
});


// create table data
function createTable() {
    if (localStorage.studentList) {
    var table_content = ``;

    $(document).ready(function () {
            jQuery('#studentTable').html(table_content);
            table_content += '<tr ><th >Firstname</th><th >Lastname</th><th >Email</th><th >Location</th><th >Phone</th><th >Address</th><th >Show More</th><th >Edit</th><th >Delete</th></thead>'

            for (var i = 0; i < dropdownVal; i++) {
                table_content += '<tr id="tr_' + i + '"><td >' + jsonData[i].firstname + '</td>';
                table_content += '<td >' + jsonData[i].lastname + '</td>';
                table_content += '<td >' + jsonData[i].email + '</td>';
                table_content += '<td >' + jsonData[i].location + '</td>';
                table_content += '<td >' + jsonData[i].phone + '</td>';
                table_content += '<td >' + $.fn.mergeObj(jsonData[i].address) + '</td>';
                table_content += '<td ><a href="#" id="show_' + i + '" style="color: darkred">Show</a></td>';
                table_content += '<td ><a href="#" id="edit_' + i + '" style="color: darkred">Edit</a></td>';
                table_content += '<td ><a href="#" id="delete_' + i + '" style="color: darkred">Delete</a></td>';
                table_content += '</tr>';
            }

            table_content += '</table>';
            jQuery('#studentTable').html(table_content);
            $(".table_data").show();

        });

    } else {
        $.ajax({
            "type": "GET",
            "url": "student.json",
            "datatype": "JSON",
            "success": function (data) {
                localStorage.setItem("studentList", JSON.stringify(data));
            },
            "error": function () {
                alert('Error! Could not retrieve json data.');
            }
        });
    }
}

//Delete table data

jQuery(document).on('click', 'a[id^="delete_"]', function (event) {
    event.preventDefault();

    var idSplit = jQuery(this).attr('id').split('_'),
        rowID = 'tr_' + idSplit[1];
    jQuery('#' + rowID).closest('tr').remove();
    jsonData.splice(idSplit[1],1)
    localStorage.setItem("studentList", JSON.stringify(jsonData));
    //createTable();
});

//Show more data
jQuery(document).on('click', 'a[id^="show_"]', function (event) {
    event.preventDefault();

    var idSplit = jQuery(this).attr('id').split('_'),
        rowID = 'tr_' + idSplit[1];
    index=idSplit[1];

    if (jsonData[index] != '') {
        var _table_content = "<table style='border-collapse:collapse;'>";
        _table_content += '<tr ><th >Marks</th></tr>';
        _table_content += '<td >' + '<strong>English :</strong>' + jsonData[index].marks.english + "<br>" + '<strong>Science:</strong>' + jsonData[index].marks.science + "<br>" 
        + '<strong>Computer:</strong>' + jsonData[index].marks.computers + "<br>" +'<strong>Hardware :</strong>' + jsonData[index].marks.hardware + '</td>';
       _table_content += '</tr>';
        _table_content += '</table>';

        jQuery('#' + rowID).after('<tr><td colspan="2">'+_table_content+'</td></tr>');
        jsonData[index] = '';
    }

    else {
        jQuery('#' + rowID).next().toggle(_table_content);
    }

});
//Display Edit data on form
jQuery(document).on('click', 'a[id^="edit_"]', function () {

    $("#inputsubmit").hide();
    $("#inputupdate").show();
    var idSplit = jQuery(this).attr('id').split('_'),
        rowID = 'tr_' + idSplit[1];
    index=idSplit[1];

    for(var i=0;i<jsonData.length;i++) {
        if (i == index) {
            $("#firstname").val(jsonData[index].firstname);
            $("#lastname").val(jsonData[index].lastname);
            $("#email").val(jsonData[index].email);
            $("#location").val(jsonData[index].location);
            $("#phone").val(jsonData[index].phone);
            $("#comms").val(jsonData[index].address.communication);
            $("#perm").val(jsonData[index].address.permanent);
            $("#english").val(jsonData[index].marks.english);
            $("#science").val(jsonData[index].marks.science);
            $("#computer").val(jsonData[index].marks.computers);
            $("#hardware").val(jsonData[index].marks.hardware);
        }
    }
});

//Update edit data
$("#inputupdate").click(function(){

    jsonData[index].firstname = $("#firstname").val();
    jsonData[index].lastname = $("#lastname").val(),
    jsonData[index].email = $("#email").val(),
    jsonData[index].location = $("#location").val(),
    jsonData[index].phone = $("#phone").val(),
    jsonData[index].address.communication = $("#comms").val(),
    jsonData[index].address.permanent = $("#perm").val(),
    jsonData[index].marks.english = $("#english").val(),
    jsonData[index].marks.science = $("#science").val(),
    jsonData[index].marks.computers = $("#computer").val(),
    jsonData[index].marks.hardware = $("#hardware").val(),

    localStorage.setItem("studentList", JSON.stringify(jsonData));
    createTable();
    regForm.reset();
    $("#inputupdate").hide();
    $("#inputsubmit").show();
});

//Create new entry
function register() {

    var firstname = document.getElementById("firstname").value;
    var lastname = document.getElementById('lastname').value;
    var email = document.getElementById('email').value;
    var location = document.getElementById('location').value;
    var phone = document.getElementById('phone').value;
    var communication = document.getElementById('comms').value;
    var permanent = document.getElementById('perm').value;
    var english =document.getElementById('english').value;
    var science =document.getElementById('science').value;
    var computers =document.getElementById('computer').value;
    var hardware = document.getElementById('hardware').value;

    var newUser = {
        firstname: firstname,
        lastname: lastname,
        email: email,
        location: location,
        phone: phone,
        address: {
            communication: communication,
            permanent: permanent
        },
        marks: {
            english: english,
            science: science,
            computers: computers,
            hardware: hardware
        }
    }

    jsonData.push(newUser);
    localStorage.setItem('studentList', JSON.stringify(jsonData));
    createTable();
    regForm.reset();

    return true;
}

//Search Box
$(document).ready(function()
{
    $('#search').keyup(function()
    {
        searchTableData($(this).val());
    });
});

function searchTableData(inputVal)
{
    var table = $('#studentTable');
    table.find('tr').each(function(_index, row)
    {
        var allCells = $(row).find('td');
        if(allCells.length > 0)
        {
            var found = false;
            allCells.each(function(_index, td)
            {
                var regExp = new RegExp(inputVal, 'i');
                if(regExp.test($(td).text()))
                {
                    found = true;
                    return false;
                }
            });
            if(found == true)$(row).show();else $(row).hide();
        }
    });
}

// Add drag n drop func
document.addEventListener('dragstart', function (event) {
    event.dataTransfer.setData('Text', event.target.innerHTML);
});
